const request = require('supertest');
const app = require('../app');
const { db, admin } = require('../config/db');
const moment = require('moment');

var currentHour = moment().utcOffset(180).hour();
if (currentHour < 13) {
    var date = moment().utcOffset(180).format('YYYY-MM-DD');
} else {
    var date = moment().utcOffset(180).add(1, 'day').format('YYYY-MM-DD');
}

describe('reserve', () => {
    before(function(done){
        db.ref('/reservations').remove();
        var hours = [16]
        var plateNo = Math.floor(Math.random()) * 1000;
        for (var i = 0; i < 4; i++) {
            var price = 5;
            db.ref('/reservations').push().set({
                carPlateNo: `${plateNo}`,
                date: date,
                price: price,
                status: 'created',
                zoneName: 'CBAE Female & Male Zone',
                resNo: i,
                extendedHours: 0,
                cancelledHours: 0,
                uid: '12 35 98 15',
                time: hours
            })
        }
        done();
    })

    it('should restricts, No available spots', function(done) {
        request(app).post(`/api/reserve`)
            .send({
                "date": date,
                "time": "16:00",
                "userID": "F63u7dysn5bNhn6Ahzm3H2eI3s22",
                "zones": "CBAE Female & Male Zone",
                "hours": 1
            })
            .expect(200)
            .expect("This time 16 is already reserved, please try another time or another zone", done)
    });

    it("should add reserve", (done) => {
        request(app).post(`/api/reserve`)
            .send({
                "date": date,
                "time": "19:00",
                "userID": "F63u7dysn5bNhn6Ahzm3H2eI3s22",
                "zones": "CBAE Female & Male Zone",
                "hours": 1
            })
            .expect(200)
            .expect("successfully reserved", done)
    })

})

function restrict(){
    var time;
    db.ref('/reservations').remove();
        if(currentHour < 13){
            var date = moment().format('YYYY-MM-DD');
            var hours = [[14,15, 16], [17], [18]]
        } else {
            var date = moment().add(1,'day').format('YYYY-MM-DD');
            var hours = [[6,7],[8],[9],[10]]
        }
        for (var i = 0; i < hours.length; i++) {
            var price = hours[i].length * 5;
            db.ref('/reservations').push().set({
                carPlateNo: '12315',
                date: date,
                price: price,
                status: 'created',
                zoneName: 'CBAE Female & Male Zone',
                resNo: i,
                extendedHours: 0,
                cancelledHours: 0,
                uid: '12 35 98 15',
                time: hours[i]
            })
        }
}

describe('reserve', () => {
    it('should restricts more than 6 res for user', function(done) {
        if(currentHour < 13){
            time = '19:00'
        } else {
            time = '11:00'
        }
        restrict();
        request(app).post(`/api/reserve`)
            .send({
                "date": date,
                "time": time,
                "userID": "F63u7dysn5bNhn6Ahzm3H2eI3s22",
                "zones": "CBAE Female & Male Zone",
                "hours": 2
            })
            .expect(200)
            .expect("Sorry! You can’t reserve more as your reservations exceed 6 hours", done)
    });

    it('should restricts, user have already reserved', function(done) {
        if(currentHour < 13){
            time = '18:00'
        } else {
            time = '10:00'
        }
        restrict();
        request(app).post(`/api/reserve`)
            .send({
                "date": date,
                "time": time,
                "userID": "F63u7dysn5bNhn6Ahzm3H2eI3s22",
                "zones": "CBAE Female & Male Zone",
                "hours": 1
            })
            .expect(200)
            .expect("You can’t reserve, as you have already reserved at this time and zone", done)
    });
})

describe('extend', function () {
    var reserveID;
    before(function (done) {
        db.ref('/reservations').remove();
        var price = 5;
        var resHour = moment().utcOffset(180).hour();
        var hours = [resHour]
        var newReserve = db.ref('/reservations').push();
        reserveID = newReserve.key;
        newReserve.set({
            carPlateNo: `12315`,
            date: date,
            price: price,
            status: 'created',
            zoneName: 'CBAE Female & Male Zone',
            resNo: '15',
            extendedHours: 0,
            cancelledHours: 0,
            uid: '12 35 98 15',
            time: hours
        })
        done();
    })
    it('should extend hours!', function (done) {
        request(app).post(`/extend`)
            .send({
                "reserveID": reserveID
            })
            .expect(200)
            .expect("Reservation extended", done)
    })
})

describe('cancel', function () {
    var reserveID;
    before(function (done) {
        db.ref('/reservations').remove();
        var price = 5;
        var resHour = moment().utcOffset(180).hour();
        var hours = [resHour + 4]
        var newReserve = db.ref('/reservations').push();
        reserveID = newReserve.key;
        newReserve.set({
            carPlateNo: `12315`,
            date: date,
            price: price,
            status: 'created',
            zoneName: 'CBAE Female & Male Zone',
            resNo: '5',
            extendedHours: 0,
            cancelledHours: 0,
            uid: '12 35 98 15',
            time: hours
        })
        done();
    })
    it('should cancel the reservation', function (done) {
        request(app).post(`/cancel`)
            .send({
                "reserveID": reserveID
            })
            .expect(200)
            .expect("Reservation was cancelled Successfully!", done)
    })
})


describe('cancel', function () {
    var reserveID;
    before(function (done) {
        db.ref('/reservations').remove();
        var price = 5;
        var resHour = moment().utcOffset(180).hour();
        var hours = [resHour, resHour + 1, resHour + 2]
        var newReserve = db.ref('/reservations').push();
        reserveID = newReserve.key;
        newReserve.set({
            carPlateNo: `12315`,
            date: date,
            price: price,
            status: 'created',
            zoneName: 'CBAE Female & Male Zone',
            resNo: '15',
            extendedHours: 0,
            cancelledHours: 0,
            uid: '12 35 98 15',
            time: hours
        })
        done();
    })
    it('should sub-cancel the reservation', function (done) {
        request(app).post(`/cancel`)
            .send({
                "reserveID": reserveID
            })
            .expect(200)
            .expect("Reservation was cancelled Successfully!", done)
    })
})

describe('histogram', function () {
    it('should add history', function (done) {
        request(app).get('/statistics')
            .expect(200)
            .expect('Bravo', done)
    })
})

module.exports = app;